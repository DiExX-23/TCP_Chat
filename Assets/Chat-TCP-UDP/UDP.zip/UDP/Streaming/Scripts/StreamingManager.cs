using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Simple coordinator to start client/server streaming with minimal UI wiring.
/// Keep this class lightweight: it only wires modules, toggles and UI preview.
/// </summary>
public class StreamingManager : MonoBehaviour
{
    public bool isServer = false;
    public string remoteAddress = "127.0.0.1";
    public int localPort = 5555;
    public int remotePort = 5555;

    public UdpTransport transport;
    public VideoSender videoSender;
    public VideoReceiver videoReceiver;
    public AudioSender audioSender;
    public AudioReceiver audioReceiver;
    public AudioPlayer audioPlayer;

    public RawImage remoteVideoDisplay;
    public RawImage localPreviewDisplay;

    /// <summary>
    /// Start transport and modules, wire targets, and show local preview if available.
    /// </summary>
    public void StartStreaming()
    {
        if (transport != null)
        {
            transport.StartTransport(localPort, remoteAddress, remotePort, bindLocal: true);
        }

        // Assign transport and UI targets
        if (videoReceiver != null) videoReceiver.targetImage = remoteVideoDisplay;
        if (videoSender != null) videoSender.transport = transport;
        if (videoReceiver != null) videoReceiver.transport = transport;
        if (audioSender != null) audioSender.transport = transport;
        if (audioReceiver != null) audioReceiver.transport = transport;

        if (audioReceiver != null && audioPlayer != null)
        {
            audioPlayer.Initialize(audioReceiver.audioQueue);
        }

        // Enable receivers and start senders
        if (videoReceiver != null) videoReceiver.enabled = true;

        if (videoSender != null)
        {
            videoSender.StartSending();

            // assign local preview; ensure visible and not tinted
            if (localPreviewDisplay != null)
            {
                localPreviewDisplay.texture = videoSender.CameraTexture;
                localPreviewDisplay.color = Color.white;
                localPreviewDisplay.enabled = true;
            }
        }

        if (audioReceiver != null) audioReceiver.enabled = true;
        if (audioSender != null) audioSender.StartSending();
    }

    /// <summary>
    /// Stop senders and transport; clear local preview so last frame doesn't remain visible.
    /// </summary>
    public void StopStreaming()
    {
        if (videoSender != null) videoSender.StopSending();
        if (audioSender != null) audioSender.StopSending();
        if (transport != null) transport.StopTransport();

        // Clear preview texture to avoid showing last frame
        if (localPreviewDisplay != null)
        {
            localPreviewDisplay.texture = null;
            // optionally disable the RawImage to hide the control:
            // localPreviewDisplay.enabled = false;
        }
    }

    /// <summary>
    /// Toggle video sending on or off; update local preview accordingly.
    /// </summary>
    public void ToggleVideo(bool on)
    {
        if (videoSender == null) return;

        if (on)
        {
            videoSender.StartSending();
            if (localPreviewDisplay != null)
            {
                localPreviewDisplay.texture = videoSender.CameraTexture;
                localPreviewDisplay.color = Color.white;
                localPreviewDisplay.enabled = true;
            }
        }
        else
        {
            videoSender.StopSending();
            if (localPreviewDisplay != null)
            {
                localPreviewDisplay.texture = null;
                // localPreviewDisplay.enabled = false;
            }
        }
    }

    /// <summary>
    /// Toggle audio sending on or off.
    /// </summary>
    public void ToggleAudio(bool on)
    {
        if (audioSender == null) return;

        if (on) audioSender.StartSending();
        else audioSender.StopSending();
    }

    /// <summary>
    /// Called by InputField.OnEndEdit(string) to set remote IP.
    /// </summary>
    public void SetIP(string ip)
    {
        if (string.IsNullOrWhiteSpace(ip)) return;
        remoteAddress = ip.Trim();
    }

    /// <summary>
    /// Called by InputField.OnEndEdit(string) to set remote port.
    /// </summary>
    public void SetPort(string portString)
    {
        if (int.TryParse(portString, out int p) && p >= 0 && p <= 65535)
        {
            remotePort = p;
        }
    }
}